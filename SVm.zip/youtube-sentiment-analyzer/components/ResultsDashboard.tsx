import React from 'react';
import { VideoDetails, SentimentDistribution, CommentWithSentiment, Sentiment } from '../types.ts';
import SentimentChart from './SentimentChart.tsx';
import CommentList from './CommentList.tsx';
import { ThumbsUpIcon, ThumbsDownIcon, MessageSquareIcon } from './icons.tsx';

interface ResultsDashboardProps {
    videoDetails: VideoDetails;
    sentimentDistribution: SentimentDistribution;
    classifiedComments: CommentWithSentiment[];
}

const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: string; color: string }> = ({ icon, label, value, color }) => (
    <div className={`bg-slate-800 p-4 rounded-lg flex items-center gap-4 border-l-4 ${color}`}>
        <div className="text-3xl">{icon}</div>
        <div>
            <div className="text-slate-400 text-sm">{label}</div>
            <div className="text-xl font-bold text-slate-100">{value}</div>
        </div>
    </div>
);

const ResultsDashboard: React.FC<ResultsDashboardProps> = ({ videoDetails, sentimentDistribution, classifiedComments }) => {
    const positiveComments = classifiedComments.filter(c => c.sentiment === Sentiment.Positive);
    const neutralComments = classifiedComments.filter(c => c.sentiment === Sentiment.Neutral);
    const negativeComments = classifiedComments.filter(c => c.sentiment === Sentiment.Negative);

    return (
        <div className="mt-8 space-y-8 animate-fade-in">
            <section className="bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-700">
                 <h2 className="text-2xl font-bold text-slate-100 mb-4 truncate" title={videoDetails.title}>
                    Analysis for: <span className="text-blue-400">{videoDetails.title}</span>
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <StatCard 
                        icon={<ThumbsUpIcon />} 
                        label="Total Likes" 
                        value={videoDetails.likes.toLocaleString()}
                        color="border-green-500"
                    />
                     <StatCard 
                        icon={<ThumbsDownIcon />} 
                        label="Total Dislikes" 
                        value={videoDetails.dislikes.toLocaleString()}
                        color="border-red-500"
                    />
                    <StatCard 
                        icon={<MessageSquareIcon />} 
                        label="Analyzed Comments" 
                        value={sentimentDistribution.total.toLocaleString()}
                        color="border-blue-500"
                    />
                </div>
            </section>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <section className="lg:col-span-1 bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-700">
                    <h3 className="text-xl font-semibold text-slate-100 mb-4 text-center">Sentiment Distribution</h3>
                    <SentimentChart distribution={sentimentDistribution} />
                </section>
                
                <section className="lg:col-span-2 space-y-6">
                    <CommentList title="Positive Comments" comments={positiveComments} sentiment={Sentiment.Positive} />
                    <CommentList title="Negative Comments" comments={negativeComments} sentiment={Sentiment.Negative} />
                    <CommentList title="Neutral Comments" comments={neutralComments} sentiment={Sentiment.Neutral} />
                </section>
            </div>
        </div>
    );
};

export default ResultsDashboard;