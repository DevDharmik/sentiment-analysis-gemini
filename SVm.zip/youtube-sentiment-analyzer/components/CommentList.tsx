import React from 'react';
import { CommentWithSentiment, Sentiment } from '../types.ts';
import { ThumbsUpIcon, ThumbsDownIcon, MinusCircleIcon } from './icons.tsx';

interface CommentListProps {
    title: string;
    comments: CommentWithSentiment[];
    sentiment: Sentiment;
}

const sentimentConfig = {
    [Sentiment.Positive]: {
        icon: <ThumbsUpIcon className="text-green-400" />,
        borderColor: 'border-green-500',
        bgColor: 'bg-green-900/20'
    },
    [Sentiment.Negative]: {
        icon: <ThumbsDownIcon className="text-red-400" />,
        borderColor: 'border-red-500',
        bgColor: 'bg-red-900/20'
    },
    [Sentiment.Neutral]: {
        icon: <MinusCircleIcon className="text-slate-400" />,
        borderColor: 'border-slate-600',
        bgColor: 'bg-slate-700/20'
    },
};

const CommentList: React.FC<CommentListProps> = ({ title, comments, sentiment }) => {
    if (comments.length === 0) {
        return null;
    }

    const config = sentimentConfig[sentiment];

    return (
        <div className={`bg-slate-800 p-4 rounded-xl shadow-lg border border-slate-700 ${config.bgColor}`}>
            <h4 className="text-lg font-semibold mb-3 flex items-center gap-2 text-slate-200">
                {config.icon} {title} ({comments.length})
            </h4>
            <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
                {comments.slice(0, 10).map((comment) => (
                    <div key={comment.id} className={`p-3 rounded-lg border-l-4 ${config.borderColor} bg-slate-900`}>
                        <p className="text-slate-300 text-sm">"{comment.text}"</p>
                        <p className="text-right text-xs text-slate-500 mt-2">- {comment.author}</p>
                    </div>
                ))}
                 {comments.length > 10 && (
                    <p className="text-center text-xs text-slate-500 pt-2">...and {comments.length - 10} more.</p>
                )}
            </div>
        </div>
    );
};

export default CommentList;