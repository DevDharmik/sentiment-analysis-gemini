import React, { useState, useCallback } from 'react';
import { generateMockYouTubeData, analyzeCommentSentiments } from './services/geminiService.ts';
import { VideoDetails, SentimentDistribution, CommentWithSentiment, Sentiment } from './types.ts';
import UrlInputForm from './components/UrlInputForm.tsx';
import ResultsDashboard from './components/ResultsDashboard.tsx';
import Loader from './components/Loader.tsx';
import { YoutubeIcon } from './components/icons.tsx';

const App: React.FC = () => {
    const [videoDetails, setVideoDetails] = useState<VideoDetails | null>(null);
    const [classifiedComments, setClassifiedComments] = useState<CommentWithSentiment[] | null>(null);
    const [sentimentDistribution, setSentimentDistribution] = useState<SentimentDistribution | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);

    const handleUrlSubmit = useCallback(async (url: string) => {
        setIsLoading(true);
        setError(null);
        setVideoDetails(null);
        setClassifiedComments(null);
        setSentimentDistribution(null);

        try {
            // Step 1: Generate mock data for the video
            const details = await generateMockYouTubeData(url);
            setVideoDetails(details);

            // Step 2: Analyze the sentiments of the fetched comments
            const sentimentResults = await analyzeCommentSentiments(details.comments);

            // Step 3: Combine original comments with sentiment results
            const commentsWithSentiment = details.comments.map(comment => {
                const result = sentimentResults.find(r => r.id === comment.id);
                return {
                    ...comment,
                    sentiment: result ? result.sentiment : Sentiment.Neutral, // Default to Neutral if not found
                };
            });
            setClassifiedComments(commentsWithSentiment);

            // Step 4: Calculate sentiment distribution for the chart
            const distribution: SentimentDistribution = {
                Positive: 0,
                Neutral: 0,
                Negative: 0,
                total: commentsWithSentiment.length,
            };

            commentsWithSentiment.forEach(comment => {
                distribution[comment.sentiment]++;
            });
            setSentimentDistribution(distribution);

        } catch (err) {
            console.error(err);
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    }, []);

    return (
        <div className="min-h-screen bg-slate-900 flex flex-col items-center p-4 sm:p-6 md:p-8 font-sans">
            <header className="w-full max-w-5xl text-center mb-8">
                <div className="flex items-center justify-center gap-4 mb-2">
                    <YoutubeIcon className="w-16 h-16 text-red-500" />
                    <h1 className="text-4xl sm:text-5xl font-bold text-slate-100 tracking-tight">
                        YouTube Sentiment Analyzer
                    </h1>
                </div>
                <p className="text-lg text-slate-400">
                    Use AI to gauge the reaction to any YouTube video.
                </p>
            </header>

            <main className="w-full max-w-5xl">
                <UrlInputForm onSubmit={handleUrlSubmit} isLoading={isLoading} />

                {isLoading && <Loader />}

                {error && (
                    <div className="mt-8 p-4 bg-red-900/50 border border-red-700 rounded-lg text-red-200 text-center">
                        <p className="font-semibold">An Error Occurred</p>
                        <p>{error}</p>
                    </div>
                )}
                
                {!isLoading && !error && videoDetails && sentimentDistribution && classifiedComments && (
                    <ResultsDashboard
                        videoDetails={videoDetails}
                        sentimentDistribution={sentimentDistribution}
                        classifiedComments={classifiedComments}
                    />
                )}
            </main>
        </div>
    );
};

export default App;