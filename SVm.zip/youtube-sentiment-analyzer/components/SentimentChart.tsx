import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { SentimentDistribution, Sentiment } from '../types.ts';

interface SentimentChartProps {
    distribution: SentimentDistribution;
}

const COLORS = {
    [Sentiment.Positive]: '#22c55e', // green-500
    [Sentiment.Negative]: '#ef4444', // red-500
    [Sentiment.Neutral]: '#64748b',  // slate-500
};

const SentimentChart: React.FC<SentimentChartProps> = ({ distribution }) => {
    const data = [
        { name: 'Positive', value: distribution.Positive },
        { name: 'Negative', value: distribution.Negative },
        { name: 'Neutral', value: distribution.Neutral },
    ].filter(d => d.value > 0);

    return (
        <div style={{ width: '100%', height: 300 }}>
            <ResponsiveContainer>
                <PieChart>
                    <Pie
                        data={data}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        nameKey="name"
                        label={({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
                            const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
                            const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
                            const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));
                            return (
                                <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central" fontSize="14">
                                    {`${(percent * 100).toFixed(0)}%`}
                                </text>
                            );
                        }}
                    >
                        {data.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[entry.name as Sentiment]} />
                        ))}
                    </Pie>
                    <Tooltip
                        contentStyle={{
                            backgroundColor: '#1e293b', // slate-800
                            borderColor: '#334155', // slate-700
                            borderRadius: '0.5rem',
                        }}
                        itemStyle={{ color: '#cbd5e1' }} // slate-300
                    />
                    <Legend iconType="circle" />
                </PieChart>
            </ResponsiveContainer>
        </div>
    );
};

export default SentimentChart;