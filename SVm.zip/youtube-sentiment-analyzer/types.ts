
export enum Sentiment {
  Positive = 'Positive',
  Neutral = 'Neutral',
  Negative = 'Negative',
}

export interface Comment {
  id: string;
  author: string;
  text: string;
}

export interface VideoDetails {
  title: string;
  likes: number;
  // dislikes are deprecated in youtube api, but we can generate them for flavour
  dislikes: number; 
  comments: Comment[];
}

export interface CommentWithSentiment extends Comment {
  sentiment: Sentiment;
}

export interface SentimentDistribution {
  [Sentiment.Positive]: number;
  [Sentiment.Neutral]: number;
  [Sentiment.Negative]: number;
  total: number;
}
