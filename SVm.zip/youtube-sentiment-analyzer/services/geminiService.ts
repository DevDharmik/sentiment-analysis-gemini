import { GoogleGenAI, Type } from "@google/genai";
import { VideoDetails, Comment, Sentiment } from '../types.ts';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const MOCK_DATA_MODEL = 'gemini-2.5-flash';
const ANALYSIS_MODEL = 'gemini-2.5-flash';

const videoDetailsSchema = {
    type: Type.OBJECT,
    properties: {
        title: { type: Type.STRING, description: "A creative, plausible title for the video." },
        likes: { type: Type.INTEGER, description: "A realistic number of likes, e.g., between 500 and 200000." },
        dislikes: { type: Type.INTEGER, description: "A realistic number of dislikes, much lower than likes." },
        comments: {
            type: Type.ARRAY,
            description: "A list of 50 realistic and varied comments.",
            items: {
                type: Type.OBJECT,
                properties: {
                    id: { type: Type.STRING, description: "A unique identifier for the comment, e.g., comment-1, comment-2." },
                    author: { type: Type.STRING, description: "A plausible YouTube username." },
                    text: { type: Type.STRING, description: "The content of the comment. Ensure a mix of positive, negative, and neutral sentiments." },
                },
                required: ["id", "author", "text"],
            },
        },
    },
    required: ["title", "likes", "dislikes", "comments"],
};

export const generateMockYouTubeData = async (videoUrl: string): Promise<VideoDetails> => {
    try {
        const prompt = `You are a mock API server. For a supposed YouTube video at the URL "${videoUrl}", generate a realistic JSON object representing its metadata. The video is about a popular tech review. The JSON should contain a plausible video title, a like count, a dislike count, and an array of exactly 50 varied user comments. The comments must represent a mix of positive, negative, and neutral feedback.`;
        
        const response = await ai.models.generateContent({
            model: MOCK_DATA_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: videoDetailsSchema,
            },
        });
        
        const jsonText = response.text.trim();
        const data = JSON.parse(jsonText);
        
        // Basic validation
        if (!data.title || !data.comments || data.comments.length === 0) {
            throw new Error("Generated data is missing required fields.");
        }
        
        return data as VideoDetails;

    } catch (error) {
        console.error("Error generating mock YouTube data:", error);
        throw new Error("Failed to generate mock data from AI. The model may have returned an invalid format.");
    }
};

const sentimentAnalysisSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            id: { type: Type.STRING, description: "The original ID of the comment." },
            sentiment: { 
                type: Type.STRING, 
                enum: [Sentiment.Positive, Sentiment.Neutral, Sentiment.Negative],
                description: `The sentiment of the comment.`
            },
        },
        required: ["id", "sentiment"],
    },
};

export const analyzeCommentSentiments = async (comments: Comment[]): Promise<{ id: string, sentiment: Sentiment }[]> => {
    try {
        const commentsJson = JSON.stringify(comments.map(c => ({id: c.id, text: c.text})));
        const prompt = `You are an expert sentiment analysis model. For the following JSON array of YouTube comments, classify the sentiment of each comment's text as either "Positive", "Neutral", or "Negative". Your response must be a JSON array where each object contains the original 'id' and the resulting 'sentiment'. Do not include the original text in your response.

        Input Comments:
        ${commentsJson}
        `;

        const response = await ai.models.generateContent({
            model: ANALYSIS_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: sentimentAnalysisSchema,
            },
        });

        const jsonText = response.text.trim();
        const analysisResults = JSON.parse(jsonText);
        
        if (!Array.isArray(analysisResults) || analysisResults.some(r => !r.id || !r.sentiment)) {
            throw new Error("Sentiment analysis returned data in an unexpected format.");
        }

        return analysisResults as { id: string, sentiment: Sentiment }[];
    } catch (error) {
        console.error("Error analyzing comment sentiments:", error);
        throw new Error("Failed to analyze sentiments with AI. The model may have returned an invalid format.");
    }
};