import React, { useState } from 'react';
import { LinkIcon } from './icons.tsx';

interface UrlInputFormProps {
    onSubmit: (url: string) => void;
    isLoading: boolean;
}

const UrlInputForm: React.FC<UrlInputFormProps> = ({ onSubmit, isLoading }) => {
    const [url, setUrl] = useState<string>('https://www.youtube.com/watch?v=dQw4w9WgXcQ');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (url.trim()) {
            onSubmit(url);
        }
    };

    return (
        <div className="bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-700">
            <form onSubmit={handleSubmit}>
                <label htmlFor="youtube-url" className="block text-sm font-medium text-slate-300 mb-2">
                    Enter YouTube Video URL
                </label>
                <div className="flex flex-col sm:flex-row gap-4">
                    <div className="relative flex-grow">
                         <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                        <input
                            id="youtube-url"
                            type="url"
                            value={url}
                            onChange={(e) => setUrl(e.target.value)}
                            placeholder="e.g., https://www.youtube.com/watch?v=..."
                            required
                            className="w-full bg-slate-900 border border-slate-600 rounded-md py-2 pl-10 pr-4 text-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition"
                            disabled={isLoading}
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={isLoading}
                        className="w-full sm:w-auto px-6 py-2 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 disabled:bg-slate-600 disabled:cursor-not-allowed transition-colors duration-200 flex items-center justify-center gap-2"
                    >
                        {isLoading ? 'Analyzing...' : 'Analyze'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default UrlInputForm;